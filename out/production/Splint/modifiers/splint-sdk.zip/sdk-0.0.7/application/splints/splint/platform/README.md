# Platform #

This is a package/modular part of the functionalities of splint. It provides development support.

__This package is compulsory when running Unit Tests.___

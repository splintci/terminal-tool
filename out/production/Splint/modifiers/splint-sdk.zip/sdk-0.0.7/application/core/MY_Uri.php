<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Uri extends CI_Uri {

  public $appsegments = array();
  public $apprsegments = array();
}
?>

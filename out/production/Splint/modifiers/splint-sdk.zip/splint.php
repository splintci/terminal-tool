<?php
/**
 * Splint Production Server Package and Dependency Manager.
 * (c) CynoBit 2019
 * Date Created: 22/2/2019 11:06 AM
 * Author: Francis Ilechukwu
 * Email:  francis.ilechukwu@cynobit.com
 */
function installPackages($splint) {

}
// A 'splint.json' file is required to execute this script further.
if (!is_file("splint.json")) die("Could not find a 'splint.json' file.");
$data = json_decode(file_get_contents("splint.json"));
if (!isset($data["install"])) die("No packages found to install");
$splints = $data["install"];
?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SplintTest extends CI_Controller {
  function index() {
    $this->load->splint("francis94c/ci-preference", "-hello");
  }
}
?>
